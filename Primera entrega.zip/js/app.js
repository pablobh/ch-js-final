/*
* TODO: 
* - Sumar el valor de la cotización 
* - Sumar la cantidad de días para la entrega
* - Quitar un servicio de la cotización
* - Pedir los datos de contacto antes de mandar la cotización final
* - Mostrar el IVA al final
* - Sumar el valor de la cotización + IVA
* - Cupón de descuento (?)
*/

// Creo el array cotización que contendrá el listado completo de servicios
var cotizacion = []

// Función para crear los objetos que se irán agregando a la cotización
function agregarACotizacion (categoria, nombre, entrega, precio) {
    let servicio = {
        categoria: categoria,
        nombre: nombre,
        entrega: entrega,
        precio: precio
    }
    cotizacion.push(servicio);
    Swal.fire({
        position: 'top-end',
        toast: true,
        icon: 'success',
        title: 'Servicio agregado',
        showConfirmButton: false,
        timer: 1500
    })
}

// Reseteo la cotización
function limpiarCotizacion() {
    cotizacion = [];
    Swal.fire({
        position: 'top-end',
        toast: true,
        icon: 'error',
        title: 'Cotización límpia',
        showConfirmButton: false,
        timer: 1500
    })
}

// Muestro el estado actual de la cotización
function revisarCotizacion() {
    console.table(cotizacion);
    Swal.fire({
        position: 'top-end',
        toast: true,
        icon: 'info',
        title: '¡Revisa la consola! 😃',
        showConfirmButton: false,
        timer: 1500
    })
}

// Agregando productos para probar y confirmar que todo esté ok
// agregarACotizacion('branding', 'Paquete completo', 10, 1000000);
// agregarACotizacion('web', 'Paquete completo', 8, 15000000);
// agregarACotizacion('fotografia', 'Paquete completo', 18, 400000);
// agregarACotizacion('seo', 'Paquete completo', 36, 500000);
// agregarACotizacion('video', 'Paquete completo', 14, 2000000);
// agregarACotizacion('social media', 'Paquete completo', 2, 2500000);
// agregarACotizacion('copywriting', 'Paquete completo', 8, 1700000);